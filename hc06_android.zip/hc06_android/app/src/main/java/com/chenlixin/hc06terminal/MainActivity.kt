package com.chenlixin.hc06terminal

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.AdapterView
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chenlixin.hc06terminal.databinding.ActivityMainBinding
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val settingsPrefs = "app_settings"
    private val keyTxEncoding = "tx_encoding"
    private val keyTxLineEnding = "tx_line_ending"
    private val keyRxEncoding = "rx_encoding"
    private val txEncodingNames = listOf("GB2312", "UTF-8", "ASCII")
    private var txEncodingName = "UTF-8"
    private var encodingSpinnerInitialized = false
    private var rxEncodingName = "UTF-8"
    private var rxEncodingSpinnerInitialized = false
    private val lineEndingNames = listOf("无", "\\n", "\\r\\n")
    private var lineEndingName = "无"
    private var lineEndingSpinnerInitialized = false
    private var selectedDevice: BluetoothDevice? = null
    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var connected = false
    private val ioExecutor = Executors.newFixedThreadPool(3)
    private val connecting = AtomicBoolean(false)
    private var deviceNames: List<String> = emptyList()
    private var deviceList: List<BluetoothDevice> = emptyList()
    private val deviceMap = linkedMapOf<String, BluetoothDevice>()
    private var discoveryReceiverRegistered = false
    private var pendingConnectAddress: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastDevice: BluetoothDevice? = null
    private var reconnectAttempts = 0
    private var reconnecting = false
    private var manualDisconnect = false
    private val maxReconnectAttempts = 5
    private val rxBuffer = StringBuilder()
    private var loggedIn = false
    private var autoSaveEnabled = false
    private var autoSaveMinutes = 0
    private val autoSaveRunnable = Runnable {
        if (autoSaveEnabled && loggedIn) {
            saveLogToFile(true)
            scheduleAutoSave()
        }
    }

    private val enableBluetoothLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshPairedDevices()
        }

    private val exportLogLauncher =
        registerForActivityResult(CreateDocument("text/plain")) { uri ->
            if (uri == null) {
                appendLog("日志导出已取消")
                return@registerForActivityResult
            }
            val text = binding.logText.text?.toString().orEmpty()
            try {
                contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                }
                appendLog("日志导出成功")
            } catch (e: Exception) {
                appendLog("日志导出失败: ${e.message}")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupLogScrolling()
        setupTxEncodingSpinner()
        setupLineEndingSpinner()
        setupRxEncodingSpinner()
        ensureDiscoveryReceiver()

        binding.refreshButton.setOnClickListener { refreshPairedDevices() }
        binding.scanButton.setOnClickListener { startClassicDiscovery() }
        binding.connectButton.setOnClickListener { connectSelected() }
        binding.disconnectButton.setOnClickListener { disconnect(true) }
        binding.unpairButton.setOnClickListener { unpairSelected() }
        binding.sendButton.setOnClickListener { sendText(binding.sendInput.text?.toString().orEmpty()) }
        binding.exportButton.setOnClickListener { exportLog() }
        binding.manageAccountsButton.setOnClickListener {
            startActivity(Intent(this, AccountManageActivity::class.java))
        }
        binding.logoutButton.setOnClickListener { logout() }
        binding.autoSaveButton.setOnClickListener { toggleAutoSave() }
        binding.cmdSend1.setOnClickListener { sendText(binding.cmdInput1.text?.toString().orEmpty()) }
        binding.cmdSend2.setOnClickListener { sendText(binding.cmdInput2.text?.toString().orEmpty()) }
        binding.cmdSend3.setOnClickListener { sendText(binding.cmdInput3.text?.toString().orEmpty()) }
        binding.cmdSend4.setOnClickListener { sendText(binding.cmdInput4.text?.toString().orEmpty()) }

        binding.deviceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                selectedDevice = deviceList.getOrNull(position)
                val name = deviceNames.getOrNull(position) ?: ""
                appendLog("已选择设备: $name")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedDevice = null
            }
        }

        ensureBluetoothEnabled()
        refreshPairedDevices()
        loggedIn = true
        updateUiByLogin(true)
    }

    private fun setupLogScrolling() {
        binding.logScroll.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> v.parent?.requestDisallowInterceptTouchEvent(true)
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        binding.logScroll.viewTreeObserver.addOnScrollChangedListener {
            autoScrollLog = isLogAtBottom()
        }
    }

    private var autoScrollLog = true

    private fun isLogAtBottom(): Boolean {
        val content = binding.logScroll.getChildAt(0) ?: return true
        val diff = content.bottom - (binding.logScroll.height + binding.logScroll.scrollY)
        return diff <= (12 * resources.displayMetrics.density).toInt()
    }

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    appendLog("开始扫描附近蓝牙设备")
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    appendLog("扫描结束")
                }
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val d = device ?: return
                    val addr = d.address ?: return
                    deviceMap[addr] = d
                    updateDeviceSpinner()
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val d = device ?: return
                    val addr = d.address ?: return
                    val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)
                    if (state == BluetoothDevice.BOND_BONDED) {
                        appendLog("配对成功: ${d.name ?: "Unknown"} ($addr)")
                        deviceMap[addr] = d
                        updateDeviceSpinner()
                        if (pendingConnectAddress == addr) {
                            pendingConnectAddress = null
                            selectedDevice = d
                            connectSelected()
                        }
                    } else if (state == BluetoothDevice.BOND_NONE) {
                        appendLog("已取消配对: ${d.name ?: "Unknown"} ($addr)")
                        deviceMap.remove(addr)
                        if (selectedDevice?.address == addr) {
                            selectedDevice = null
                        }
                        updateDeviceSpinner()
                    }
                }
            }
        }
    }

    private fun unpairSelected() {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val device = selectedDevice
        if (device == null) {
            appendLog("请先选择要删除的设备")
            return
        }
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothPermissions()
            return
        }
        val addr = device.address
        if (socket?.isConnected == true && addr != null && addr == lastDevice?.address) {
            disconnect(true)
        }
        if (device.bondState != BluetoothDevice.BOND_BONDED) {
            if (addr != null) {
                deviceMap.remove(addr)
                updateDeviceSpinner()
            }
            appendLog("已从列表移除: ${device.name ?: "Unknown"} (${addr ?: "?"})")
            return
        }
        val ok = runCatching {
            val m = device.javaClass.getMethod("removeBond")
            (m.invoke(device) as? Boolean) ?: true
        }.getOrDefault(false)
        if (ok) {
            appendLog("已发起取消配对，请稍候")
        } else {
            appendLog("取消配对失败")
        }
    }

    private fun ensureDiscoveryReceiver() {
        if (discoveryReceiverRegistered) {
            return
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(this, discoveryReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        discoveryReceiverRegistered = true
    }

    private fun ensureBluetoothEnabled() {
        if (bluetoothAdapter == null) {
            appendLog("设备不支持蓝牙")
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetoothLauncher.launch(intent)
        }
    }

    private fun refreshPairedDevices() {
        if (bluetoothAdapter == null) {
            appendLog("设备不支持蓝牙")
            return
        }
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothPermissions()
            return
        }
        val bonded = bluetoothAdapter.bondedDevices?.toList().orEmpty()
        deviceMap.clear()
        bonded.forEach { d ->
            val addr = d.address ?: return@forEach
            deviceMap[addr] = d
        }
        updateDeviceSpinner()
        appendLog("已配对设备数量: ${bonded.size}")
    }

    private fun updateDeviceSpinner() {
        val devices = deviceMap.values.toList()
        deviceList = devices
        deviceNames = devices.map { device ->
            val name = device.name ?: "Unknown"
            val addr = device.address ?: "?"
            val tag = if (device.bondState == BluetoothDevice.BOND_BONDED) "已配对" else "附近"
            "$name ($addr) [$tag]"
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, deviceNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.deviceSpinner.adapter = adapter
    }

    private fun hasBluetoothScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun startClassicDiscovery() {
        if (bluetoothAdapter == null) {
            appendLog("设备不支持蓝牙")
            return
        }
        if (!hasBluetoothScanPermission()) {
            requestBluetoothPermissions()
            return
        }
        bluetoothAdapter.cancelDiscovery()
        val ok = bluetoothAdapter.startDiscovery()
        if (!ok) {
            appendLog("启动扫描失败")
        }
    }

    private fun connectSelected() {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val device = selectedDevice
        if (device == null) {
            appendLog("请先选择HC-06设备")
            return
        }
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothPermissions()
            return
        }
        startConnectFlow(device, allowPairing = true)
    }

    private fun startConnectFlow(device: BluetoothDevice, allowPairing: Boolean) {
        if (!connecting.compareAndSet(false, true)) {
            appendLog("正在连接中，请稍候")
            return
        }
        ioExecutor.execute {
            try {
                bluetoothAdapter?.cancelDiscovery()
                disconnect(true)
                val s = connectWithRetries(device)
                socket = s
                inputStream = s.inputStream
                outputStream = s.outputStream
                lastDevice = device
                reconnectAttempts = 0
                reconnecting = false
                manualDisconnect = false
                setConnected(true)
                runOnUiThread { appendLog("连接成功: ${device.name ?: "Unknown"} (${device.address ?: "?"})") }
                startReadLoop()
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                runOnUiThread { appendLog("连接失败: $msg") }
                val needPair = allowPairing && device.bondState != BluetoothDevice.BOND_BONDED
                if (needPair) {
                    val addr = device.address
                    pendingConnectAddress = addr
                    val ok = runCatching { device.createBond() }.getOrDefault(false)
                    if (ok) {
                        runOnUiThread { appendLog("已发起配对请求，请在系统弹窗确认PIN(常见1234/0000)") }
                        return@execute
                    }
                    runOnUiThread { appendLog("配对请求失败，请先在系统蓝牙里完成配对后再连接") }
                }
                disconnect(false)
            } finally {
                connecting.set(false)
            }
        }
    }

    private fun connectWithRetries(device: BluetoothDevice): BluetoothSocket {
        var lastError: Exception? = null
        for (attempt in 1..3) {
            try {
                runOnUiThread { appendLog("正在连接(${attempt}/3): ${device.name ?: "Unknown"}") }
                val s = createSppSocket(device)
                s.connect()
                return s
            } catch (e: Exception) {
                lastError = e
                runOnUiThread { appendLog("连接尝试失败(${attempt}/3): ${e.message ?: e.javaClass.simpleName}") }
                Thread.sleep(500L * attempt)
            }
        }
        throw lastError ?: IllegalStateException("连接失败")
    }

    private fun startReadLoop() {
        ioExecutor.execute {
            val buffer = ByteArray(1024)
            while (socket?.isConnected == true) {
                try {
                    val count = inputStream?.read(buffer) ?: -1
                    if (count < 0) {
                        runOnUiThread { appendLog("连接已关闭") }
                        disconnect(false)
                        break
                    }
                    if (count > 0) {
                        val bytes = buffer.copyOfRange(0, count)
                        handleReceived(bytes)
                    }
                } catch (e: Exception) {
                    runOnUiThread { appendLog("接收异常: ${e.message}") }
                    disconnect(false)
                    break
                }
            }
        }
    }

    private fun sendText(text: String) {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val out = outputStream
        if (socket?.isConnected != true || out == null) {
            val dev = selectedDevice
            val devText = if (dev == null) "未选择设备" else "${dev.name ?: "Unknown"} (${dev.address ?: "?"})"
            appendLog("未连接HC-06，无法发送: $devText")
            return
        }
        if (text.isBlank()) {
            appendLog("发送内容为空")
            return
        }
        ioExecutor.execute {
            try {
                val bytes = if (binding.hexSendCheck.isChecked) {
                    parseHex(text)
                } else {
                    (text + selectedLineEnding()).toByteArray(selectedTxCharset())
                }
                out.write(bytes)
                out.flush()
                runOnUiThread {
                    if (binding.hexSendCheck.isChecked) {
                        appendLog("TX HEX: ${bytesToHex(bytes)}")
                    } else {
                        appendLog("TX(${txEncodingName},${lineEndingName}): $text")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { appendLog("发送失败: ${e.message}") }
                disconnect(false)
            }
        }
    }

    private fun logout() {
        disconnect(true)
        stopAutoSave()
        loggedIn = false
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun disconnect(manual: Boolean) {
        manualDisconnect = manual
        try {
            inputStream?.close()
        } catch (_: Exception) {
        }
        try {
            outputStream?.close()
        } catch (_: Exception) {
        }
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        inputStream = null
        outputStream = null
        setConnected(false)
        runOnUiThread { appendLog("已断开连接") }
        if (!manualDisconnect) {
            scheduleReconnect()
        }
    }

    private fun setConnected(value: Boolean) {
        connected = value
        runOnUiThread { updateUiByConnection() }
    }

    private fun updateUiByConnection() {
        val canOperate = loggedIn
        val canSend = loggedIn && connected
        binding.sendInput.isEnabled = canOperate
        binding.encodingSpinner.isEnabled = canOperate
        binding.lineEndingSpinner.isEnabled = canOperate
        binding.rxEncodingSpinner.isEnabled = canOperate
        binding.hexSendCheck.isEnabled = canOperate
        binding.cmdInput1.isEnabled = canOperate
        binding.cmdInput2.isEnabled = canOperate
        binding.cmdInput3.isEnabled = canOperate
        binding.cmdInput4.isEnabled = canOperate
        binding.sendButton.isEnabled = canSend
        binding.cmdSend1.isEnabled = canSend
        binding.cmdSend2.isEnabled = canSend
        binding.cmdSend3.isEnabled = canSend
        binding.cmdSend4.isEnabled = canSend
    }

    private fun createSppSocket(device: BluetoothDevice): BluetoothSocket {
        runCatching { return device.createInsecureRfcommSocketToServiceRecord(sppUuid) }
        runCatching { return device.createRfcommSocketToServiceRecord(sppUuid) }
        runCatching {
            val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            return method.invoke(device, 1) as BluetoothSocket
        }
        throw IllegalStateException("无法创建SPP Socket")
    }

    private fun appendLog(message: String) {
        val shouldAutoScroll = autoScrollLog || isLogAtBottom()
        val current = binding.logText.text?.toString().orEmpty()
        val updated = if (current.isBlank()) message else current + "\n" + message
        binding.logText.text = updated
        if (shouldAutoScroll) {
            binding.logScroll.post {
                binding.logScroll.fullScroll(android.view.View.FOCUS_DOWN)
            }
        }
    }

    private fun setupTxEncodingSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, txEncodingNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.encodingSpinner.adapter = adapter

        val saved = getSharedPreferences(settingsPrefs, MODE_PRIVATE)
            .getString(keyTxEncoding, "UTF-8")
            .orEmpty()
        val index = txEncodingNames.indexOf(saved).takeIf { it >= 0 } ?: txEncodingNames.indexOf("UTF-8")
        txEncodingName = txEncodingNames.getOrNull(index) ?: "UTF-8"
        binding.encodingSpinner.setSelection(index, false)

        binding.encodingSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val name = txEncodingNames.getOrNull(position) ?: "UTF-8"
                txEncodingName = name
                getSharedPreferences(settingsPrefs, MODE_PRIVATE).edit()
                    .putString(keyTxEncoding, name)
                    .apply()
                if (encodingSpinnerInitialized) {
                    appendLog("发送编码: $name")
                } else {
                    encodingSpinnerInitialized = true
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun setupLineEndingSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, lineEndingNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.lineEndingSpinner.adapter = adapter

        val saved = getSharedPreferences(settingsPrefs, MODE_PRIVATE)
            .getString(keyTxLineEnding, "无")
            .orEmpty()
        val index = lineEndingNames.indexOf(saved).takeIf { it >= 0 } ?: lineEndingNames.indexOf("无")
        lineEndingName = lineEndingNames.getOrNull(index) ?: "无"
        binding.lineEndingSpinner.setSelection(index, false)

        binding.lineEndingSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val name = lineEndingNames.getOrNull(position) ?: "无"
                lineEndingName = name
                getSharedPreferences(settingsPrefs, MODE_PRIVATE).edit()
                    .putString(keyTxLineEnding, name)
                    .apply()
                if (lineEndingSpinnerInitialized) {
                    appendLog("发送结尾: $name")
                } else {
                    lineEndingSpinnerInitialized = true
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun setupRxEncodingSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, txEncodingNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.rxEncodingSpinner.adapter = adapter

        val saved = getSharedPreferences(settingsPrefs, MODE_PRIVATE)
            .getString(keyRxEncoding, "UTF-8")
            .orEmpty()
        val index = txEncodingNames.indexOf(saved).takeIf { it >= 0 } ?: txEncodingNames.indexOf("UTF-8")
        rxEncodingName = txEncodingNames.getOrNull(index) ?: "UTF-8"
        binding.rxEncodingSpinner.setSelection(index, false)

        binding.rxEncodingSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val name = txEncodingNames.getOrNull(position) ?: "UTF-8"
                rxEncodingName = name
                getSharedPreferences(settingsPrefs, MODE_PRIVATE).edit()
                    .putString(keyRxEncoding, name)
                    .apply()
                if (rxEncodingSpinnerInitialized) {
                    appendLog("接收编码: $name")
                } else {
                    rxEncodingSpinnerInitialized = true
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun selectedLineEnding(): String {
        return when (lineEndingName) {
            "\\n" -> "\n"
            "\\r\\n" -> "\r\n"
            else -> ""
        }
    }

    private fun selectedRxCharset(): Charset {
        return when (rxEncodingName) {
            "GB2312" -> runCatching { Charset.forName("GB2312") }.getOrDefault(Charsets.UTF_8)
            "ASCII" -> Charsets.US_ASCII
            else -> Charsets.UTF_8
        }
    }

    private fun selectedTxCharset(): Charset {
        return when (txEncodingName) {
            "GB2312" -> runCatching { Charset.forName("GB2312") }.getOrDefault(Charsets.UTF_8)
            "ASCII" -> Charsets.US_ASCII
            else -> Charsets.UTF_8
        }
    }

    private fun handleReceived(bytes: ByteArray) {
        runOnUiThread {
            if (binding.hexDisplayCheck.isChecked) {
                appendLog("RX HEX [${beijingTime()}]: ${bytesToHex(bytes)}")
            }
        }
        if (binding.hexDisplayCheck.isChecked) {
            return
        }
        val textChunk = try {
            String(bytes, selectedRxCharset())
        } catch (_: Exception) {
            ""
        }
        if (textChunk.isNotEmpty()) {
            rxBuffer.append(textChunk)
            var index = rxBuffer.indexOf("\n")
            while (index >= 0) {
                val line = rxBuffer.substring(0, index).trimEnd('\r')
                rxBuffer.delete(0, index + 1)
                if (line.isNotBlank()) {
                    runOnUiThread { appendLog("RX(${rxEncodingName}) [${beijingTime()}]: $line") }
                    if (binding.parseCheck.isChecked) {
                        runOnUiThread { appendLog(parseLine(line)) }
                    }
                }
                index = rxBuffer.indexOf("\n")
            }
            if (index < 0 && !binding.hexDisplayCheck.isChecked) {
                runOnUiThread { appendLog("RX片段(${rxEncodingName}) [${beijingTime()}]: ${textChunk.take(80)}") }
            }
        }
    }

    private fun parseLine(line: String): String {
        return when {
            line.contains("=") -> {
                val parts = line.split("=", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                "解析: $key = $value"
            }
            line.contains(":") -> {
                val parts = line.split(":", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                "解析: $key : $value"
            }
            line.contains(",") -> {
                val parts = line.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (parts.isEmpty()) {
                    "解析: 空数据"
                } else {
                    "解析: 列表(${parts.size}) ${parts.joinToString(" | ")}"
                }
            }
            else -> "解析: $line"
        }
    }

    private fun parseHex(text: String): ByteArray {
        val cleaned = text.replace("0x", "", ignoreCase = true).replace("\\s".toRegex(), "")
        if (cleaned.isEmpty() || cleaned.length % 2 != 0) {
            throw IllegalArgumentException("十六进制格式错误")
        }
        val bytes = ByteArray(cleaned.length / 2)
        var i = 0
        while (i < cleaned.length) {
            val byteStr = cleaned.substring(i, i + 2)
            bytes[i / 2] = byteStr.toInt(16).toByte()
            i += 2
        }
        return bytes
    }

    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString(" ") { "%02X".format(it) }
    }

    private fun scheduleReconnect() {
        if (reconnecting || lastDevice == null || !loggedIn) {
            return
        }
        if (reconnectAttempts >= maxReconnectAttempts) {
            appendLog("自动重连已停止")
            reconnecting = false
            return
        }
        reconnecting = true
        reconnectAttempts += 1
        val delayMs = 1000L * (1 shl (reconnectAttempts - 1)).coerceAtMost(16)
        appendLog("将在${delayMs / 1000}秒后自动重连")
        mainHandler.postDelayed({
            reconnecting = false
            if (socket?.isConnected == true) {
                return@postDelayed
            }
            connectLastDevice()
        }, delayMs)
    }

    private fun connectLastDevice() {
        val device = lastDevice ?: return
        selectedDevice = device
        connectSelected()
    }

    private fun exportLog() {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis())
        val fileName = "hc06_log_$timestamp.txt"
        exportLogLauncher.launch(fileName)
    }

    private fun toggleAutoSave() {
        if (autoSaveEnabled) {
            stopAutoSave()
            return
        }
        val minutes = binding.autoSaveMinutesInput.text?.toString().orEmpty().trim().toIntOrNull()
        if (minutes == null || minutes <= 0) {
            appendLog("请输入有效的保存间隔(分钟)")
            return
        }
        autoSaveMinutes = minutes
        autoSaveEnabled = true
        binding.autoSaveButton.text = "关闭"
        binding.autoSaveStatus.text = "自动保存已开启: ${autoSaveMinutes}分钟"
        scheduleAutoSave()
        appendLog("自动保存已开启: ${autoSaveMinutes}分钟")
    }

    private fun scheduleAutoSave() {
        mainHandler.removeCallbacks(autoSaveRunnable)
        if (!autoSaveEnabled || autoSaveMinutes <= 0) {
            return
        }
        val delay = autoSaveMinutes * 60_000L
        mainHandler.postDelayed(autoSaveRunnable, delay)
    }

    private fun stopAutoSave() {
        autoSaveEnabled = false
        autoSaveMinutes = 0
        mainHandler.removeCallbacks(autoSaveRunnable)
        binding.autoSaveButton.text = "开启"
        binding.autoSaveStatus.text = "自动保存未开启"
        appendLog("自动保存已关闭")
    }

    private fun saveLogToFile(auto: Boolean) {
        val text = binding.logText.text?.toString().orEmpty()
        if (text.isBlank()) {
            if (!auto) {
                appendLog("日志为空")
            }
            return
        }
        val dir = getExternalFilesDir(null) ?: filesDir
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("Asia/Shanghai")
        }.format(System.currentTimeMillis())
        val fileName = "hc06_log_${if (auto) "auto_" else ""}$timestamp.txt"
        val file = File(dir, fileName)
        try {
            file.writeText(text, Charsets.UTF_8)
            if (auto) {
                appendLog("自动保存日志: ${file.name}")
            } else {
                appendLog("已保存日志: ${file.name}")
            }
        } catch (e: Exception) {
            appendLog("保存日志失败: ${e.message}")
        }
    }

    private fun beijingTime(): String {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
        return format.format(System.currentTimeMillis())
    }

    private fun updateUiByLogin(enabled: Boolean) {
        binding.refreshButton.isEnabled = enabled
        binding.scanButton.isEnabled = enabled
        binding.connectButton.isEnabled = enabled
        binding.disconnectButton.isEnabled = enabled
        binding.unpairButton.isEnabled = enabled
        binding.exportButton.isEnabled = enabled
        binding.deviceSpinner.isEnabled = enabled
        binding.hexDisplayCheck.isEnabled = enabled
        binding.parseCheck.isEnabled = enabled
        binding.manageAccountsButton.isEnabled = enabled
        binding.autoSaveMinutesInput.isEnabled = enabled
        binding.autoSaveButton.isEnabled = enabled
        if (!enabled) {
            stopAutoSave()
            setConnected(false)
        }
        updateUiByConnection()
    }

    private fun hasBluetoothConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                ),
                1001
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1002
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1001 && requestCode != 1002) {
            return
        }
        val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (granted) {
            appendLog("蓝牙权限已授予")
            refreshPairedDevices()
        } else {
            appendLog("蓝牙权限被拒绝，无法连接/发送")
        }
    }

    override fun onDestroy() {
        disconnect(true)
        if (discoveryReceiverRegistered) {
            runCatching { unregisterReceiver(discoveryReceiver) }
            discoveryReceiverRegistered = false
        }
        connecting.set(false)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}
